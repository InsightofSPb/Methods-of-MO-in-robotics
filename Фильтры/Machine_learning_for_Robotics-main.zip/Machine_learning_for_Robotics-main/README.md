# Machine_learning_for_Robotics

In this course I solved the following robotics tasks:<br />
1- Classification using pretrained and untrained NNs. Data Augmentation was used to increase performance<br />
2- Localization: using three methods: baysain rule, Kalman filter and particles filter<br />
3- Reinforcement learning: using Q-table, and QNN<br />
